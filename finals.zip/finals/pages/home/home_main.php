<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="pages/home/home_style.css">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="desktop1">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
  <div style= "width: 5%">
    <img src="image/decs.png" class="card-img-top" alt="...">
    </div>
    <a class="navbar-brand" href="#">DECS COFFEE SHOP</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a onclick="to_home()" class="nav-link active" aria-current="page" href="#">HOME</a>
        </li>
        <li class="nav-item">
          <a onclick="to_product()"class="nav-link" href="#">PRODUCT</a>
        </li>

        <li class="nav-item">
          <a onclick="to_contact_us()" class="nav-link" href="#">CONTACT US</a>
        </li>
        <li class="nav-item">
          <a onclick="to_about_us()" onclick="to_about_us()" class="nav-link" href="#">ABOUT US</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            LOGOUT
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
         
            <li><a class="dropdown-item" onclick="to_login()" href="#">LOG OUT</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
          <img class="Rectangle1" src="image/backgroundd.png" alt="">
          <p class="HappinessBeginsWithCoffee">HAPPINESS BEGINS <br/>WITH COFFEE</p>
          <p class="AwakenYourSenses">Awaken your senses with the irresistible aroma and rich, velvety taste of our handcrafted coffee- a brew  designed to make every morning extraordinary.<br/></p>
           <div class="Line1"></div>
           <p class="FreeDelivery">FREE<br/>DELIVERY</p>
           <p class="OrderNow">ORDER NOW<br/>0975-057-2101</p> 
          <input type="button" onclick="to_product()" value="BUY NOW" class="BuyNow" >
           
         
    </div>
    </div>
</body>
</html>
<script>
    function to_home(){
    $.post("pages/home/home_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_product(){
    $.post("pages/product/product_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_admin(){
    $.post("admin/admin_login.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}

function to_contact_us(){
    $.post("pages/contact us/contact_us_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_about_us(){
    $.post("pages/about us/about_us_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}

function to_profile(){
    $.post("pages/profile/profile_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}

function to_user(){
    $.post("pages/user list/user_list_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
 function to_login(){
     $.post("pages/login/login_main.php", {}, function (data) {
        $("#pages").html(data);
            
         });

 }
</script>
