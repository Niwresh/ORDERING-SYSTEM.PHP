<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="pages/billing/billing_style.css">
    <title>Document</title>
</head>
<body>
    
<div class="container">
<div class="Desktop1">
    <img src="image/decs.png" alt="" class="decs">
<div class="Rectangle1"></div>
<input type="button" class="button" onclick="to_product()" value=" CANCEL ORDER" >
<input type="text" name="prod" id="prod">
<input type="button" class="Button" onclick="to_profile()" value="ORDER" >
<p class="payment">Confirm Your Payment</p>
<p class="order">Ordered Product:</p>
<p class="quantity">Quantity:</p>
<input type="number" name="Quantity" id="Quantity">
<p class="cost">Cost:</p>
<input type="number" name="Cost" id="Cost">
<p class="Payment">Payment:</p>
<p class="COD">Cash On delivery</p>






</div>
</div>
</body>
</html>
