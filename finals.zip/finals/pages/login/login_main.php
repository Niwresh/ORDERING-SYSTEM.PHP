<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="pages/login/login_style.css">
    <title>Login Page</title>
</head>
<body>
        <div class="container">
        <div class="Desktop1">
        <div class="Rectangle1">
        <img class="Rectangle2" src="image/circles brown.jpg" />
        <img class="Ellipse11" src="image/decs.png" />
        <div class="Rectangle10"></div>
        <p class="blend" >THE PERFECT BLEND</p>
        <p class="login" >LOGIN</p>
        <input type="button" value="LOGIN" onclick="to_home()" name="login" id="LOGIN" >
        <p class="or" >OR</p>
        <!-- <input type="image" class="facebook" src="image/download.png" alt=""> -->
        <a href ="https://www.facebook.com/">
              <img src="image/download.png" class="facebook"  ></a></p>
        <!-- <input type="image" class="google" src="image/download (1).png" alt=""> -->
        <a href ="https://mail.google.com/">
              <img src="image/download (1).png" class="google"  ></a></p>
        <input type="button" value="REGISTER" onclick="to_registration()" name="regis" id="REGISTER" >
        <img class="Ellipse13" src="image/d.jpg" />
        <img class="Ellipse14" src="image/email.jpg" />
        <p class="EmailPhone" >EMAIL/PHONE:</p>
        <input type="email" name="email" id="email" placeholder="ENTER EMAIL" required>
        <p class="pass" >PASSWORD:</p>
        <img class="Rectangle11" src="image/images.jpg" />
        <input type="password" name="password" id="pass" placeholder="ENTER PASSWORD">
        <input type="checkbox" name="check" id="checkbox">
        <p class="remember" >Remember Me!!</p>
        <p class="forgot" >Forget Password?</p>
       
        </div>
      </div>
    </div>


</body>
</html>


<script>
    function to_home(){
    $.post("pages/home/home_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}

function to_registration(){
    $.post("pages/register/register_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>
</body>
</html>



