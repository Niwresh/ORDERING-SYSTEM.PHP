<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="pages/profile/profile_style.css">
    <title>Document</title>
</head>
<body>
   <div class="container">
    <div class="Desktop2">
        <img src="image/images.png" alt="" class="login" >
        <div class="rectangle1"></div>
        <img src="image/coffeelogo.png" alt="" class="Picture">
        <input type="button" class="bttn" onclick="to_product()" value="CONFIRM ORDER" >
        <input type="image" class="back" src="image/back.png" onclick="to_home()">
        <p class="firstName">First Name:</p>
        <input type="text" name="name" id="name">
        <p class="middleName">Middle Name:</p>
        <input type="text" name="midname" id="midname">
        <p class="lastName">Last Name:</p>
        <input type="text" name="lastname" id="lastname">
        <p class="phoneno">Phone No:</p>
        <input type="number" name="phoneno" id="phoneno">
        <p class="houseno">House No:</p>
        <input type="number" name="houseno" id="houseno">
        <p class="street">Street:</p>
        <input type="text" name="street" id="street">
        <p class="barangay">Barangay:</p>
        <input type="text" name="barangay" id="barangay">
        <p class="municipality">Municipality/City:</p>
        <input type="text" name="municipality" id="municipality">
        <p class="province">Province:</p>
        <input type="text" name="province" id="province">
        <p class="zipcode">Zipcode:</p>
        <input type="number" name="zipcode" id="zipcode">
        <div class="line1"></div>
      <p class="profile">Profile:</p>
     
      
    </div>
   </div>
</body>
</html>

<script>
    function to_about_us(){
    $.post("pages/about us/about_us_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>