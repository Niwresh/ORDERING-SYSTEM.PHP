<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="pages/register/regis_style.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
    <div class="Desktop1">
    <img class="Ellipse1" src="image/decs.png" />
    <div class="Rectangle2"></div>
    <p class="first" >FIRSTNAME:</p>
    <input type="text" class="textF1" placeholder="ENTER FIRSTNAME" maxlength="15" required>
    <p class="last" >LASTNAME:</p>
    <input type="text" class="textF2" placeholder="ENTER LASTNAME" maxlength="15" required >
    <p class="phone" >PHONE NUMBER:</p>
    <input type="number" class="textF3" placeholder="ENTER PHONE NUMBER">
    <p class="email" >EMAIL:</p>
    <input type="email" class="textF4" placeholder="ENTER EMAIL" >
    <p class="pass" >PASSWORD:</p>
    <input type="password" class="textF5" placeholder="ENTER PASSWORD" >
    <p class="confirm" >CONFIRM PASSWORD:</p>
    <input type="password" class="textF6" placeholder="CONFIRM PASSWORD" >
    <input type="checkbox" name="checkbox" id="check">
    <p class="agree" >I Agree To The Terms and Conditions</p>
    <input type="button" onclick="to_login()" value="REGISTER" class="reg">
    </div>

</body>
</html>

<script>
    function to_login(){
    $.post("pages/login/login_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}

</script>