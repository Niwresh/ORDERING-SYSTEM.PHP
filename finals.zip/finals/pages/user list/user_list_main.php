<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="pages/user list/user_list_style.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
    <div class="Desktop1">
    <img src="image/decs.png" alt="" class="decs">
    <img src="image/admin.png" alt="" class="adminpic">
    <img src="image/images.png" alt="" class="user">
    <p class="admin">ADMIN</p>
    <p class="User">Users:</p>
    <input type="search" name="search" id="search" placeholder ="Search">
    <input type="image" class="back" src="image/back.png" onclick="to_home()">
    <div class="Line1"></div>
    <div class="Rectangle2">

    <div class="table-container">
    <table class="table">
     
        <tr class="header" >
            <th>FULLNAME</th>
            <th>ORDER LIST</th>
            <th>EMAIL</th>
            <th>TIME STAMP</th>
            <th>ROLE</th>
            <th>ACTIOS</th>
            
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        <tr class="cell">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
       
    </table>
</div>
    </div>
    </div>
    </div>
</body>
</html>
<script>
     function to_home(){
    $.post("pages/home/home_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
</script>

