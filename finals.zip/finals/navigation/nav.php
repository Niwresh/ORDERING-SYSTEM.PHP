<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">DECS COFFEE SHOP</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a onclick="to_home()" class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a onclick="to_product()" class="nav-link" href="#">Product</a>
        </li>
        <li class="nav-item">
          <a onclick="to_contact_us()" class="nav-link" href="#">Contact Us</a>
        </li>
        <li class="nav-item">
          <a onclick="to_about_us()" onclick="to_about_us()" class="nav-link" href="#">About Us</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="pages/login/login_main.php">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>


    </div>
</body>
</html>
<script>
    function to_home(){
    $.post("pages/home/home_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_product(){
    $.post("pages/product/product_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_contact_us(){
    $.post("pages/contact us/contact_us_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
function to_about_us(){
    $.post("pages/about us/about_us_main.php", {}, function (data) {
        $("#pages").html(data);
            
        });

}
// function to_login(){
//     $.post("pages/login/login_main.php", {}, function (data) {
//         $("#nav").html(data);
            
//         });

// }
</script>
