<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="admin_home/admin_home_style.css">
    <link rel="stylesheet" href="user list/user_list_style.css">
    <link rel="stylesheet" href="ordered list/order_style.css">
    <title>Document</title>
</head>
<body>
    
    <div id="admin123" >
    </div>
    





    <!--SCRIPTS-->
    <script src="assets/js/jquery-3.6.3.js"></script>
    <script src="assets/js/global_.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

</body>
</html>
