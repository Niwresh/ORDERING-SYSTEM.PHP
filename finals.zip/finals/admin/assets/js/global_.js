$(document).ready(function () {
  to_admin();
  
    // to_navigation();
    
    
});



function to_admin(){
    $.post("admin_home/admin_home.php", {}, function (data) {
      
        $("#admin123").html(data);
            
        });

}
// 
//  function to_admin(){
//     $.post("admin/admin home/admin_home.php", {}, function (data) {
//         $("#admin").html(data);
            
//         });

//  }


 




