

<div class="container">
    <div class="desktop1">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
  <div style= "width: 5%">
    <img src="image/decs.png" class="card-img-top" alt="...">
    </div>
    <a class="navbar-brand" href="#">DECS COFFEE SHOP</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a onclick="to_home()" class="nav-link active" aria-current="page" href="#">HOME</a>
        </li>
        <li class="nav-item">
          <a onclick="to_user()" class="nav-link" href="#">USERLIST</a>
        </li>
        <li class="nav-item">
          <a onclick="to_orders()"class="nav-link" href="#">ORDER LIST</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            LOGOUT
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="http://localhost/finals/">LOG OUT</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
          <img class="Rectangle1" src="image/backgroundd.png" alt="">
          <p class="HappinessBeginsWithCoffee">HAPPINESS BEGINS <br/>WITH COFFEE</p>
          <p class="AwakenYourSenses">Awaken your senses with the irresistible aroma and rich, velvety taste of our handcrafted coffee- a brew  designed to make every morning extraordinary.<br/></p>
           <p class="FreeDelivery">FREE<br/>DELIVERY</p>
           <p class="OrderNow">ORDER NOW<br/>0975-057-2101</p> 
          <!-- <input type="button" onclick="to_product()" value="BUY NOW" class="BuyNow" > -->
    </div>
    </div>

    

<script>
   

function to_user(){
    $.post("user list/user_list.php", {}, function (data) {
        $("#admin123").html(data);
            
        });

}

function to_orders(){
    $.post("ordered list/order.php", {}, function (data) {
        $("#admin123").html(data);
            
        });

}

// function to_login(){
//      $.post("CodeStride/pages/login/login_main.php", {}, function (data) {
//         $("#pages").html(data);
            
//          });

//  }

</script>


