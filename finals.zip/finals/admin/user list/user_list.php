
    <div class="container">
    <div class="Desktop1">
    <img src="image/decs.png" alt="" class="decs">
    <img src="image/admin.png" alt="" class="adminpic">
    <img src="image/images.png" alt="" class="user">
    <p class="admin">ADMIN</p>
    <p class="User">Users:</p>
    <input type="search" name="search" id="search" placeholder ="Search">
    <input type="image" class="back" src="image/back.png" onclick="to_admin_home()">
   
    <div class="Rectangle2">

    <div class="table-container">
    <table class="table">
     
        <tr class="header" >
            <th>FULLNAME</th>
            <th>ORDER LIST</th>
            <th>EMAIL</th>
            <th>TIME STAMP</th>
            <th>ROLE</th>
            <th>ACTIOS</th>
            
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell" >
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        <tr class="cell">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
        </tr>
        <tr class="cell">
        <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
           
        </tr>
       
    </table>
</div>
    </div>
    </div>
    </div>

<script>
       function to_admin_home(){
    $.post("admin_home/admin_home.php", {}, function (data) {
        $("#admin123").html(data);
            
        });

}
</script>

