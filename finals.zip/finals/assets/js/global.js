$(document).ready(function () {
    to_dashboard();
    // to_navigation();
    
    
});

function to_dashboard(){
    $.post("pages/login/login_main.php", {}, function (data) {
        console.log(data)
        $("#pages").html(data);
            
        });

}
// function to_navigation(){
//     $.post("navigation/nav.php", {}, function (data) {
//         $("#nav").html(data);
            
//         });

// }

 




